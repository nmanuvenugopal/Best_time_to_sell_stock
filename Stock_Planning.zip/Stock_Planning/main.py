price_list = input("Enter the price list: ").split(',')
price_list = list(map(int, price_list))
print(price_list)

# We can not find the Maximum and Minimum value and then subtract to get profit.
# Because we can only sell stock after one day of buying it.
# Maximum value can be the first element, so that way is not possible.

# We need to iterate through the different elements to get the max profit
def best_time_to_sell_stock(prices):
    max_profit = 0
    for i in range(0, len(prices)-1):
        for j in range(i+1, len(prices)):
            profit = prices[j] - prices[i]
            if max_profit < profit:
                max_profit = profit
    return max_profit

print(best_time_to_sell_stock(price_list))



